from django.apps import AppConfig


class Exemple1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'exemple1'
